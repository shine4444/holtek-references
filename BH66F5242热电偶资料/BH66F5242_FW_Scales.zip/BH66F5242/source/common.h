#ifndef _COMMON_H_
#define _COMMON_H_

#include "userdefine.h"
#include "typedef.h"
#include "BH66F5242.h"
#include "BH66F5242_Sys.h"
#include <stdlib.h>
#include "temp.h"
#include "Protocol.h"
#include "USIM.h"
#include "..\BH66F5242_Scales_SDK\ScalesSDK_Interface.h"
#endif
